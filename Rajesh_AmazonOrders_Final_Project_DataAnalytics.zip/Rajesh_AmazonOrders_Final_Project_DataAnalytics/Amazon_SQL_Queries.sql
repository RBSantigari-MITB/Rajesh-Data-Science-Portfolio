SELECT COUNT(*) AS Total_Rows
FROM amazon_orders;
USE data_analytics_final_project;

SELECT *
FROM amazon_orders
LIMIT 10;
SELECT SKU, SUM(`Total_Sales`) AS Total_Net_Sales, SUM(Qty) AS Total_Quantity
FROM amazon_orders
GROUP BY SKU
ORDER BY Total_Net_Sales DESC
LIMIT 10;

SELECT Category, SUM(`Total_Sales`) AS Total_Net_Sales, SUM(Qty) AS Total_Quantity
FROM amazon_orders
GROUP BY Category
ORDER BY Total_Net_Sales DESC;

SELECT Size, SUM(`Total_Sales`) AS Total_Net_Sales, SUM(Qty) AS Total_Quantity
FROM amazon_orders
GROUP BY Size
ORDER BY Total_Net_Sales DESC;

SELECT `ship-state`, SUM(`Total_Sales`) AS Total_Order_Amount
FROM amazon_orders
WHERE `ship-state` IS NOT NULL
  AND `ship-state` <> 'Unknown'
GROUP BY `ship-state`
ORDER BY Total_Order_Amount DESC
LIMIT 5;

SELECT `ship-city`, SUM(`Total_Sales`) AS Total_Order_Amount
FROM amazon_orders
WHERE `ship-city` IS NOT NULL
  AND `ship-city` <> 'Unknown'
GROUP BY `ship-city`
ORDER BY Total_Order_Amount DESC
LIMIT 5;

SELECT Category, COUNT(DISTINCT `Order ID`) AS Number_of_Orders
FROM amazon_orders
GROUP BY Category
ORDER BY Number_of_Orders DESC;

SELECT `ship-state`, COUNT(DISTINCT `Order ID`) AS Number_of_Orders
FROM amazon_orders
WHERE `ship-state` IS NOT NULL
  AND `ship-state` <> 'Unknown'
GROUP BY `ship-state`
ORDER BY Number_of_Orders DESC
LIMIT 10;

SELECT `ship-city`, COUNT(DISTINCT `Order ID`) AS Number_of_Orders
FROM amazon_orders
WHERE `ship-city` IS NOT NULL
  AND `ship-city` <> 'Unknown'
GROUP BY `ship-city`
ORDER BY Number_of_Orders DESC
LIMIT 10;

SELECT Year, Month, SUM(`Total_Sales`) AS Monthly_Revenue
FROM amazon_orders
GROUP BY Year, Month
ORDER BY Year, Month;

SELECT Fulfilment, SUM(`Total_Sales`) AS Total_Revenue, AVG(`Total_Sales`) AS Average_Order_Amount, COUNT(DISTINCT `Order ID`) AS Number_of_Orders
FROM amazon_orders
GROUP BY Fulfilment
ORDER BY Total_Revenue DESC;

SELECT `ship-service-level`, SUM(`Total_Sales`) AS Total_Revenue, AVG(`Total_Sales`) AS Average_Order_Amount, COUNT(DISTINCT `Order ID`) AS Number_of_Orders
FROM amazon_orders
GROUP BY `ship-service-level`
ORDER BY Total_Revenue DESC;

SELECT Category, SUM(Qty) AS Total_Quantity, SUM(`Total_Sales`) AS Total_Revenue, ROUND(SUM(`Total_Sales`) / NULLIF(SUM(Qty), 0), 2) AS Revenue_per_Unit
FROM amazon_orders
GROUP BY Category
ORDER BY Total_Revenue DESC;

SELECT `ship-service-level`, Category, COUNT(DISTINCT `Order ID`) AS Number_of_Orders, SUM(`Total_Sales`) AS Total_Revenue
FROM amazon_orders
GROUP BY `ship-service-level`, Category
ORDER BY `ship-service-level`, Total_Revenue DESC;

SELECT Category, COUNT(DISTINCT `Order ID`) AS Total_Orders,
    COUNT(DISTINCT CASE WHEN Status LIKE '%Cancelled%' THEN `Order ID` END) AS Cancelled_Orders,
    ROUND(COUNT(DISTINCT CASE WHEN Status LIKE '%Cancelled%' THEN `Order ID` END) * 100.0/ COUNT(DISTINCT `Order ID`),2) AS Cancellation_Rate_Percent
FROM amazon_orders
GROUP BY Category
ORDER BY Cancellation_Rate_Percent DESC;

SELECT Size, COUNT(DISTINCT `Order ID`) AS Total_Orders, COUNT(DISTINCT CASE WHEN Status LIKE '%Cancelled%' THEN `Order ID` END) AS Cancelled_Orders,
    ROUND(COUNT(DISTINCT CASE WHEN Status LIKE '%Cancelled%' THEN `Order ID` END) * 100.0 / COUNT(DISTINCT `Order ID`),2) AS Cancellation_Rate_Percent
FROM amazon_orders
GROUP BY Size
ORDER BY Cancellation_Rate_Percent DESC;

SELECT CASE WHEN `promotion-ids` = 'No Promotion' THEN 'No Promotion' ELSE 'Promotion Applied' END AS Promotion_Type,
    COUNT(DISTINCT `Order ID`) AS Number_of_Orders, SUM(`Total_Sales`) AS Total_Revenue, ROUND(AVG(`Total_Sales`), 2) AS Average_Order_Amount
FROM amazon_orders
GROUP BY Promotion_Type
ORDER BY Total_Revenue DESC;

SELECT Category, COUNT(*) AS Number_of_Rows, ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM amazon_orders),2) AS Category_Percentage
FROM amazon_orders
GROUP BY Category
ORDER BY Number_of_Rows DESC;

SELECT Size, COUNT(*) AS Number_of_Rows, ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM amazon_orders),2) AS Size_Percentage
FROM amazon_orders
GROUP BY Size
ORDER BY Number_of_Rows DESC;

SELECT Style, COUNT(*) AS Number_of_Rows, ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM amazon_orders),2) AS Style_Percentage
FROM amazon_orders
GROUP BY Style
ORDER BY Number_of_Rows DESC
LIMIT 20;

SELECT ROUND(SUM(Top10_Sales) * 100.0 / (SELECT SUM(`Total_Sales`) FROM amazon_orders),2) AS Top_10_SKU_Sales_Percentage
FROM
(
    SELECT SKU, SUM(`Total_Sales`) AS Top10_Sales
    FROM amazon_orders
    GROUP BY SKU
    ORDER BY Top10_Sales DESC
    LIMIT 10
) AS top10;

SELECT ROUND(SUM(Top50_Sales) * 100.0 / (SELECT SUM(`Total_Sales`) FROM amazon_orders),2) AS Top_50_SKU_Sales_Percentage
FROM
(
    SELECT SKU, SUM(`Total_Sales`) AS Top50_Sales
    FROM amazon_orders
    GROUP BY SKU
    ORDER BY Top50_Sales DESC
    LIMIT 50
) AS top50;